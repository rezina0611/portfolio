jQuery(function($){
 	
	$('.meta1 a').on('click', function(e){
		e.preventDefault();
		var meta1 = $(this).data('codeid');
		$('#metaCode1').val(meta1);
		$('#metaCode2').val("");
		/* if(meta1 == null || meta1 == ''){
		}
			alert(meta1); */
		if(meta1 != null && meta1 != ''){
			//alert('선택된 코드가 없습니다.');
			$('.meta2sel>li>a').text('전체');
			$('.meta2').empty();
			$('.meta2').append("<li><a href=\"#n\" data-codeid=\"\">전체</a></li>");
			
			$.ajax({
				url : '/site/main/archive/space/api/code/youth_space'
				, type : 'get'
				, data : {
					catId : meta1
				}
				, dataType: 'json'
			}).done(function(result){
				if(result.length > 0){

					$.each(result, function(index, item){
						//alert(item.codeName);
						$('.meta2').append("<li><a href=\"#n\" data-codeid='"+ item.codeId +"'>"+ item.codeName + "(" + item.cnt + ")</a></li>");
					});
				}
				
			//}).fail(function(result){
//				alert('코드를 불러오지 못하였습니다.[fail]');
			});
		}
	});
	
	$('.map_all').on('click', '.meta2 a', function(e){
		e.preventDefault();
		var meta2 = $(this).data('codeid');
		$('#metaCode2').val(meta2);
		//alert(meta2);
	});
	$('.map_all').on('click', '.meta3 a', function(e){
		e.preventDefault();
		var meta3 = $(this).data('codeid');
		$('#metaCode3').val(meta3);
	});
  
	//맵 on
	$('.gyeonggi').show();
 
 
 // 검색
	$('.searchBtn').on('click', function(e){
		e.preventDefault();
		$('#spaceSearch').submit();
	});
	
});




/*지도s*/
$(".sub-contents").on('click', '.jd_slec > li > a',function(){
    if($(this).hasClass("on")){  
        $(".jd_dps").css("display","none");
        $(this).removeClass("on");
    }else{
        $(this).addClass("on");
        $(".jd_dps").css("display","none");
        $(this).next(".jd_dps").css("display","block");
    }
});
$(".sub-contents").on('click', '.jd_dps > li > a',function(){
    $(".jd_dps").css({"display":"none"}); 
    $(this).parent("li").parent("ul").parent("li").children("a").text($(this).text());
    $(".jd_slec > li > a").removeClass("on");
    $(".maps > li > a").removeClass("on");
});

$(".sub-contents").on('click', '.maps > li > a',function(){
    $(".maps > li > a").removeClass("on");
    $(this).addClass("on");
});

$(".sub-contents").on('click', '.jd_dps_jy > li',function(){
    var index =  $(this).index();
    $(this).addClass('on').siblings().removeClass('on');
    $(".map_ps").eq(index).show().siblings().hide();
    return false;
});
/*지도s*/


